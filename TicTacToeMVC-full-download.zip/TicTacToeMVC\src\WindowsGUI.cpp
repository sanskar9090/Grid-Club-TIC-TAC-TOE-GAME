#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <windowsx.h>

#include "ttt/AI.hpp"
#include "ttt/Board.hpp"

#include <algorithm>
#include <cstdlib>
#include <cwchar>
#include <exception>
#include <iterator>
#include <string>

namespace {

constexpr wchar_t WindowClassName[] = L"TicTacToeMVCWindow";
constexpr int SizeControl = 101;
constexpr int ConnectControl = 102;
constexpr int DepthControl = 103;
constexpr int NewGameControl = 104;
constexpr int Margin = 32;
constexpr int BoardTop = 228;

struct AppState {
    ttt::Board board{3, 3};
    ttt::AI ai{4, 8};
    HWND sizeEdit = nullptr;
    HWND connectEdit = nullptr;
    HWND depthEdit = nullptr;
    HFONT headingFont = nullptr;
    HFONT bodyFont = nullptr;
    HBRUSH labelBrush = nullptr;
    HBRUSH editBrush = nullptr;
    std::wstring status = L"Your turn — place X";
    bool finished = false;
};

struct BoardRect {
    int left;
    int top;
    int side;
};

AppState* stateFrom(HWND window) {
    return reinterpret_cast<AppState*>(GetWindowLongPtrW(window, GWLP_USERDATA));
}

BoardRect boardRect(HWND window) {
    RECT client{};
    GetClientRect(window, &client);
    const int width = client.right - client.left;
    const int height = client.bottom - client.top;
    const int side = std::max(0, std::min(width - 2 * Margin, height - BoardTop - Margin));
    return {(width - side) / 2, BoardTop, side};
}

void setControlFont(HWND control, HFONT font) {
    SendMessageW(control, WM_SETFONT, reinterpret_cast<WPARAM>(font), TRUE);
}

HWND makeLabel(HWND parent, const wchar_t* text, int x, int y, int width, HFONT font) {
    HWND label = CreateWindowExW(
        0, L"STATIC", text, WS_CHILD | WS_VISIBLE,
        x, y, width, 22, parent, nullptr, GetModuleHandleW(nullptr), nullptr);
    setControlFont(label, font);
    return label;
}

void layoutControls(HWND window, AppState& state) {
    RECT client{};
    GetClientRect(window, &client);
    const int width = client.right - client.left;
    const int rowY = 171;
    const int fieldWidth = 72;
    const int gap = 18;
    const int startX = Margin;
    const int connectX = startX + fieldWidth + gap;
    const int depthX = connectX + fieldWidth + gap;
    const int buttonX = depthX + fieldWidth + 28;
    const int buttonWidth = std::max(112, std::min(150, width - buttonX - Margin));

    SetWindowPos(state.sizeEdit, nullptr, startX, rowY, fieldWidth, 32, SWP_NOZORDER);
    SetWindowPos(state.connectEdit, nullptr, connectX, rowY, fieldWidth, 32, SWP_NOZORDER);
    SetWindowPos(state.depthEdit, nullptr, depthX, rowY, fieldWidth, 32, SWP_NOZORDER);
    HWND newGame = GetDlgItem(window, NewGameControl);
    SetWindowPos(newGame, nullptr, buttonX, rowY, buttonWidth, 32, SWP_NOZORDER);
}

void drawText(HDC dc, const wchar_t* text, RECT rect, HFONT font, COLORREF color,
              UINT format = DT_LEFT | DT_VCENTER | DT_SINGLELINE) {
    SetTextColor(dc, color);
    SetBkMode(dc, TRANSPARENT);
    HFONT previous = reinterpret_cast<HFONT>(SelectObject(dc, font));
    DrawTextW(dc, text, -1, &rect, format);
    SelectObject(dc, previous);
}

void drawBoard(HDC dc, HWND window, const AppState& state) {
    const BoardRect area = boardRect(window);
    if (area.side <= 0) {
        return;
    }

    RECT board{area.left, area.top, area.left + area.side, area.top + area.side};
    HBRUSH background = CreateSolidBrush(RGB(20, 30, 48));
    FillRect(dc, &board, background);
    DeleteObject(background);

    const int size = state.board.size();
    HPEN gridPen = CreatePen(PS_SOLID, size > 12 ? 1 : 2, RGB(54, 72, 98));
    HPEN previousPen = reinterpret_cast<HPEN>(SelectObject(dc, gridPen));
    HBRUSH previousBrush = reinterpret_cast<HBRUSH>(
        SelectObject(dc, GetStockObject(HOLLOW_BRUSH)));
    for (int line = 0; line <= size; ++line) {
        const int offset = line * area.side / size;
        MoveToEx(dc, area.left + offset, area.top, nullptr);
        LineTo(dc, area.left + offset, area.top + area.side);
        MoveToEx(dc, area.left, area.top + offset, nullptr);
        LineTo(dc, area.left + area.side, area.top + offset);
    }
    SelectObject(dc, previousBrush);
    SelectObject(dc, previousPen);
    DeleteObject(gridPen);

    const int cellSide = area.side / size;
    for (int row = 0; row < size; ++row) {
        for (int col = 0; col < size; ++col) {
            const char mark = state.board.at(row, col);
            if (mark == ' ') {
                continue;
            }
            const int left = area.left + col * area.side / size;
            const int top = area.top + row * area.side / size;
            const int inset = std::max(5, cellSide / 5);
            RECT cell{left + inset, top + inset,
                      area.left + (col + 1) * area.side / size - inset,
                      area.top + (row + 1) * area.side / size - inset};
            const COLORREF color = mark == 'X' ? RGB(93, 177, 255) : RGB(255, 119, 153);
            if (mark == 'X') {
                HPEN markPen = CreatePen(PS_SOLID, std::max(2, cellSide / 14), color);
                HPEN oldPen = reinterpret_cast<HPEN>(SelectObject(dc, markPen));
                MoveToEx(dc, cell.left, cell.top, nullptr);
                LineTo(dc, cell.right, cell.bottom);
                MoveToEx(dc, cell.right, cell.top, nullptr);
                LineTo(dc, cell.left, cell.bottom);
                SelectObject(dc, oldPen);
                DeleteObject(markPen);
            } else {
                HPEN markPen = CreatePen(PS_SOLID, std::max(2, cellSide / 14), color);
                HPEN oldPen = reinterpret_cast<HPEN>(SelectObject(dc, markPen));
                HBRUSH oldBrush = reinterpret_cast<HBRUSH>(
                    SelectObject(dc, GetStockObject(HOLLOW_BRUSH)));
                Ellipse(dc, cell.left, cell.top, cell.right, cell.bottom);
                SelectObject(dc, oldBrush);
                SelectObject(dc, oldPen);
                DeleteObject(markPen);
            }
        }
    }
}

void drawWindow(HDC dc, HWND window, const AppState& state) {
    RECT client{};
    GetClientRect(window, &client);
    HBRUSH background = CreateSolidBrush(RGB(11, 17, 29));
    FillRect(dc, &client, background);
    DeleteObject(background);

    RECT heading{Margin, 24, client.right - Margin, 70};
    drawText(dc, L"TIC TAC TOE", heading, state.headingFont, RGB(237, 243, 255));
    RECT subtitle{Margin, 70, client.right - Margin, 98};
    drawText(dc, L"A classic, with a smarter opponent.", subtitle, state.bodyFont,
             RGB(149, 166, 192));
    RECT status{Margin, 104, client.right - Margin, 132};
    drawText(dc, state.status.c_str(), status, state.bodyFont, RGB(121, 197, 255));

    drawBoard(dc, window, state);
}

bool readNumber(HWND control, int& value) {
    wchar_t text[32]{};
    const int length = GetWindowTextW(control, text, static_cast<int>(std::size(text)));
    if (length <= 0) {
        return false;
    }
    wchar_t* end = nullptr;
    const long parsed = std::wcstol(text, &end, 10);
    if (end == text || *end != L'\0' || parsed < 1 || parsed > 30) {
        return false;
    }
    value = static_cast<int>(parsed);
    return true;
}

void updateStatusAfterMove(AppState& state, char mark) {
    if (state.board.hasWon(mark)) {
        state.finished = true;
        state.status = mark == 'X' ? L"You win! Start a new game to play again."
                                  : L"The computer wins. Try another game!";
    } else if (state.board.isFull()) {
        state.finished = true;
        state.status = L"It's a draw. Start a new game to play again.";
    }
}

void startNewGame(HWND window, AppState& state) {
    int size = 0;
    int connect = 0;
    int depth = 0;
    if (!readNumber(state.sizeEdit, size) || size > 30 ||
        !readNumber(state.connectEdit, connect) || connect > size ||
        !readNumber(state.depthEdit, depth) || depth > 4) {
        MessageBoxW(window,
                    L"Enter a board size from 1 to 30, a connect length from 1 to the board size, "
                    L"and an AI depth from 1 to 4.",
                    L"Check game settings", MB_OK | MB_ICONWARNING);
        return;
    }

    try {
        state.board = ttt::Board(size, connect);
        state.ai = ttt::AI(depth, 8);
        state.finished = false;
        state.status = L"Your turn — place X";
        InvalidateRect(window, nullptr, TRUE);
    } catch (const std::exception& error) {
        const std::string message = error.what();
        const std::wstring wideMessage(message.begin(), message.end());
        MessageBoxW(window, wideMessage.c_str(), L"Could not start game", MB_OK | MB_ICONERROR);
    }
}

void playCell(HWND window, AppState& state, int x, int y) {
    if (state.finished) {
        return;
    }
    const BoardRect area = boardRect(window);
    if (area.side <= 0 || x < area.left || y < area.top ||
        x >= area.left + area.side || y >= area.top + area.side) {
        return;
    }
    const int col = (x - area.left) * state.board.size() / area.side;
    const int row = (y - area.top) * state.board.size() / area.side;
    if (!state.board.play(row, col, 'X')) {
        return;
    }
    updateStatusAfterMove(state, 'X');
    if (!state.finished) {
        const ttt::SearchResult move = state.ai.chooseMove(state.board, 'O');
        state.board.play(move.row, move.col, 'O');
        updateStatusAfterMove(state, 'O');
        if (!state.finished) {
            state.status = L"Your turn — place X";
        }
    }
    InvalidateRect(window, nullptr, TRUE);
}

LRESULT CALLBACK windowProcedure(HWND window, UINT message, WPARAM wParam, LPARAM lParam) {
    AppState* state = stateFrom(window);
    if (message == WM_NCCREATE) {
        const auto* create = reinterpret_cast<const CREATESTRUCTW*>(lParam);
        state = static_cast<AppState*>(create->lpCreateParams);
        SetWindowLongPtrW(window, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(state));
    }

    switch (message) {
    case WM_CREATE: {
        state = stateFrom(window);
        state->headingFont = CreateFontW(30, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                                         DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                         CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                         DEFAULT_PITCH, L"Segoe UI");
        state->bodyFont = CreateFontW(16, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
                                      DEFAULT_CHARSET, OUT_DEFAULT_PRECIS,
                                      CLIP_DEFAULT_PRECIS, CLEARTYPE_QUALITY,
                                      DEFAULT_PITCH, L"Segoe UI");
        state->labelBrush = CreateSolidBrush(RGB(11, 17, 29));
        state->editBrush = CreateSolidBrush(RGB(235, 241, 250));
        makeLabel(window, L"BOARD SIZE", Margin, 143, 100, state->bodyFont);
        makeLabel(window, L"CONNECT", Margin + 90, 143, 80, state->bodyFont);
        makeLabel(window, L"AI DEPTH", Margin + 180, 143, 80, state->bodyFont);
        state->sizeEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"3",
            WS_CHILD | WS_VISIBLE | ES_NUMBER | ES_CENTER, 0, 0, 0, 0,
            window, reinterpret_cast<HMENU>(SizeControl), GetModuleHandleW(nullptr), nullptr);
        state->connectEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"3",
            WS_CHILD | WS_VISIBLE | ES_NUMBER | ES_CENTER, 0, 0, 0, 0,
            window, reinterpret_cast<HMENU>(ConnectControl), GetModuleHandleW(nullptr), nullptr);
        state->depthEdit = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"4",
            WS_CHILD | WS_VISIBLE | ES_NUMBER | ES_CENTER, 0, 0, 0, 0,
            window, reinterpret_cast<HMENU>(DepthControl), GetModuleHandleW(nullptr), nullptr);
        HWND newGame = CreateWindowExW(0, L"BUTTON", L"New game",
            WS_CHILD | WS_VISIBLE | WS_TABSTOP | BS_PUSHBUTTON, 0, 0, 0, 0,
            window, reinterpret_cast<HMENU>(NewGameControl), GetModuleHandleW(nullptr), nullptr);
        setControlFont(state->sizeEdit, state->bodyFont);
        setControlFont(state->connectEdit, state->bodyFont);
        setControlFont(state->depthEdit, state->bodyFont);
        setControlFont(newGame, state->bodyFont);
        layoutControls(window, *state);
        return 0;
    }
    case WM_SIZE:
        if (state != nullptr && state->sizeEdit != nullptr) {
            layoutControls(window, *state);
            InvalidateRect(window, nullptr, TRUE);
        }
        return 0;
    case WM_COMMAND:
        if (LOWORD(wParam) == NewGameControl && HIWORD(wParam) == BN_CLICKED) {
            startNewGame(window, *state);
            return 0;
        }
        break;
    case WM_CTLCOLORSTATIC: {
        HDC dc = reinterpret_cast<HDC>(wParam);
        SetTextColor(dc, RGB(149, 166, 192));
        SetBkMode(dc, TRANSPARENT);
        return reinterpret_cast<LRESULT>(state->labelBrush);
    }
    case WM_CTLCOLOREDIT: {
        HDC dc = reinterpret_cast<HDC>(wParam);
        SetTextColor(dc, RGB(24, 35, 54));
        SetBkColor(dc, RGB(235, 241, 250));
        return reinterpret_cast<LRESULT>(state->editBrush);
    }
    case WM_LBUTTONUP:
        playCell(window, *state, GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam));
        return 0;
    case WM_PAINT: {
        PAINTSTRUCT paint{};
        HDC dc = BeginPaint(window, &paint);
        drawWindow(dc, window, *state);
        EndPaint(window, &paint);
        return 0;
    }
    case WM_GETMINMAXINFO: {
        auto* limits = reinterpret_cast<MINMAXINFO*>(lParam);
        limits->ptMinTrackSize.x = 560;
        limits->ptMinTrackSize.y = 650;
        return 0;
    }
    case WM_DESTROY:
        if (state != nullptr) {
            DeleteObject(state->headingFont);
            DeleteObject(state->bodyFont);
            DeleteObject(state->labelBrush);
            DeleteObject(state->editBrush);
        }
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(window, message, wParam, lParam);
}

} // namespace

int WINAPI WinMain(HINSTANCE instance, HINSTANCE, LPSTR, int showCommand) {
    WNDCLASSEXW windowClass{};
    windowClass.cbSize = sizeof(windowClass);
    windowClass.style = CS_HREDRAW | CS_VREDRAW;
    windowClass.lpfnWndProc = windowProcedure;
    windowClass.hInstance = instance;
    windowClass.hCursor = LoadCursorW(nullptr, MAKEINTRESOURCEW(32512));
    windowClass.hbrBackground = reinterpret_cast<HBRUSH>(GetStockObject(BLACK_BRUSH));
    windowClass.lpszClassName = WindowClassName;
    if (RegisterClassExW(&windowClass) == 0) {
        MessageBoxW(nullptr, L"Could not register the game window.", L"Tic Tac Toe",
                    MB_OK | MB_ICONERROR);
        return 1;
    }

    AppState state;
    HWND window = CreateWindowExW(
        0, WindowClassName, L"Tic Tac Toe — MVC",
        WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT, 760, 900,
        nullptr, nullptr, instance, &state);
    if (window == nullptr) {
        MessageBoxW(nullptr, L"Could not create the game window.", L"Tic Tac Toe",
                    MB_OK | MB_ICONERROR);
        return 1;
    }

    ShowWindow(window, showCommand);
    UpdateWindow(window);
    MSG message{};
    while (GetMessageW(&message, nullptr, 0, 0) > 0) {
        TranslateMessage(&message);
        DispatchMessageW(&message);
    }
    return static_cast<int>(message.wParam);
}
