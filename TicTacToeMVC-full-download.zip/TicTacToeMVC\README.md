# TicTacToeMVC

A C++17 console Tic-Tac-Toe project structured around MVC, with configurable
N-by-N boards, a connect-K win condition, a minimax AI with alpha-beta pruning,
and TCP host/join multiplayer. The included HTML page is a separate browser
single-player GUI with the same search strategy and a persistent scorecard.

## Build

Requires CMake 3.16+ and a C++17 compiler. Windows uses Winsock; Linux/macOS use
POSIX sockets.

```powershell
cmake -S . -B build
cmake --build build --config Release
ctest --test-dir build --output-on-failure
```

The executable is `build\Release\tictactoe.exe` with Visual Studio generators,
or `build\tictactoe.exe` with single-configuration Windows generators.
On Windows, CMake also builds the native GUI executable
`build\Release\tictactoe-gui.exe` (or `build\tictactoe-gui.exe` with a
single-configuration generator). The GUI uses the same board model and AI as
the console game.

## Windows GUI

Launch `tictactoe-gui.exe` to play against the computer. Click an empty square
to place X; the AI responds as O. Set the board size (1–30), connect length
(1–board size), and AI search depth (1–4), then select **New game** to apply
the settings. The GUI is a native Windows application and has no additional
third-party dependencies.

To build the GUI with Visual Studio on Windows:

```powershell
cmake -S . -B build
cmake --build build --config Release
.\build\Release\tictactoe-gui.exe
```

## Play against the computer

```powershell
.\build\tictactoe.exe
.\build\tictactoe.exe --size 5 --connect 4 --depth 4
```

You play X and the computer plays O. Coordinates start at zero. Board sizes
range from 1 to 30, connect length from 1 to board size, and AI depth from 1 to
10. The depth-limited search uses alpha-beta pruning and searches nearby empty
cells to keep larger-board play practical; the AI is a heuristic opponent, not
a guarantee of perfect play. Search positions use local board values and
standard C++ containers, with no manually managed game-state allocations.

The core test executable checks board validation, win detection, and the AI's
immediate win/block decisions. Run it with `ctest --test-dir build
--output-on-failure` after building.

## TCP multiplayer

Start the host first (host is X):

```powershell
.\build\tictactoe.exe --mode host --size 5 --connect 4 --port 5050
```

Join from the other machine (joining player is O):

```powershell
.\build\tictactoe.exe --mode join --host 192.168.1.20 --port 5050
```

The host's board settings are sent to the joining player. Allow the selected TCP
port through the host firewall. This is a small trusted-peer raw TCP protocol:
it does not encrypt or authenticate traffic. It is not a WebSocket server, and
the static HTML GUI does not currently join TCP games.

## MVC layout

- `Board` is the game model and owns the board cells.
- `ConsoleView` renders the board and prompts for moves.
- `WindowsGUI` is the native Windows graphical view and uses the same `Board`
  and `AI` classes.
- `GameController` coordinates turns, win/draw checks, AI, and network moves.
- `AI` contains the heuristic minimax/alpha-beta search.
- `NetworkPeer` owns socket lifetime using RAII and exchanges newline-delimited
  configuration and move messages.
