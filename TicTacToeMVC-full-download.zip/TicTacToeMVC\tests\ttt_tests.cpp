#include "ttt/AI.hpp"
#include "ttt/Board.hpp"

#include <exception>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {

void require(bool condition, const char* message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

void testBoardValidationAndMoves() {
    bool rejected = false;
    try {
        ttt::Board invalid(0, 3);
    } catch (const std::invalid_argument&) {
        rejected = true;
    }
    require(rejected, "Board must reject an invalid size.");

    ttt::Board board(3, 3);
    require(board.play(0, 0, 'X'), "An empty cell should accept a move.");
    require(!board.play(0, 0, 'O'), "An occupied cell must reject a move.");
    require(!board.play(-1, 0, 'O'), "An out-of-bounds move must be rejected.");
    require(!board.play(1, 1, 'Z'), "An invalid mark must be rejected.");
    require(board.at(0, 0) == 'X' && board.emptyCount() == 8,
            "Rejected moves must leave the board unchanged.");
}

void testWinDetection() {
    ttt::Board horizontal(3, 3);
    horizontal.play(1, 0, 'X');
    horizontal.play(1, 1, 'X');
    horizontal.play(1, 2, 'X');
    require(horizontal.hasWon('X'), "Horizontal wins must be detected.");

    ttt::Board diagonal(3, 3);
    diagonal.play(0, 2, 'O');
    diagonal.play(1, 1, 'O');
    diagonal.play(2, 0, 'O');
    require(diagonal.hasWon('O'), "Anti-diagonal wins must be detected.");
}

void testAiTakesWinAndBlocksLoss() {
    ttt::AI ai(4, 8);

    ttt::Board winning(3, 3);
    winning.play(0, 0, 'O');
    winning.play(0, 1, 'O');
    const auto win = ai.chooseMove(winning, 'O');
    require(win.row == 0 && win.col == 2, "AI must take an immediate win.");

    ttt::Board blocking(3, 3);
    blocking.play(0, 0, 'X');
    blocking.play(0, 1, 'X');
    const auto block = ai.chooseMove(blocking, 'O');
    require(block.row == 0 && block.col == 2, "AI must block an immediate loss.");
    require(blocking.emptyCount() == 7, "AI search must not mutate the source board.");
}

} // namespace

int main() {
    try {
        testBoardValidationAndMoves();
        testWinDetection();
        testAiTakesWinAndBlocksLoss();
        std::cout << "All Tic-Tac-Toe core tests passed.\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Test failure: " << error.what() << '\n';
        return 1;
    }
}
